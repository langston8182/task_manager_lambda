from core import run_llm

def lambda_handler(event, context):
    """
    AWS Lambda démarre ici.
    La variable event contient les données entrantes (par ex. la question de l'utilisateur).
    """
    # Supposons qu'on reçoive la question dans event["question"]
    question = event.get("question", "Bonjour, y a-t-il une question ?")

    # On appelle notre logique LLM
    answer = run_llm(question, "Cyril")

    # On retourne la réponse
    return {
        "statusCode": 200,
        "body": answer
    }
